To work with Sqlite database use:
https://sqlitebrowser.org/dl/
