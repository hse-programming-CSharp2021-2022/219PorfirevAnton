﻿using System;

namespace PizzaStuff
{
    public enum Ingredients
    {
        Dough,
        Mozzarella,
        Parmesan,
        TomatoSauce,
        Peperoni,
        Olives,
        Mushrooms,
        Tomatoes,
        Herbs,
        Pineapple,
        Anchovies,
        Ham,
        OliveOil,
    }
}
