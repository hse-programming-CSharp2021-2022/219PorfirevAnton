﻿using System;

namespace PizzaStuff
{
    public sealed class Pizza
    {
        public string Name { get; init; }
        public Pizza(PizzaRecipe recipe)
        {
            throw new NotImplementedException("Method is not implemented.");
        }
    }
}
